/**********************************************************************
 *  main.cpp
 **********************************************************************
 * Copyright (C) 2015-2026 MX Authors
 *
 * Authors: Dolphin Oracle, AK-47, Adrian
 *          MX Linux <http://mxlinux.org>
 *
 * This file is part of Quick System Info.
 *
 * mx-welcome is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * mx-welcome is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with mx-welcome.  If not, see <http://www.gnu.org/licenses/>.
 **********************************************************************/

#include <QApplication>
#include <QCommandLineParser>
#include <QIcon>
#include <QLibraryInfo>
#include <QLocale>
#include <QTranslator>
#include <QMessageBox>

#include <memory>

#include "apppaths.h"
#include "mainwindow.h"
#include <unistd.h>

// VERSION should come from compilation options.
#ifndef VERSION
    #define VERSION "?.?.?.?"
#endif

int main(int argc, char *argv[])
{
    const QByteArray option = argc == 2 ? QByteArray(argv[1]) : QByteArray();
    const bool informational = option == "-h" || option == "--help" || option == "--help-all"
                               || option == "-v" || option == "--version";
    std::unique_ptr<QCoreApplication> app;
    if (informational) {
        app = std::make_unique<QCoreApplication>(argc, argv);
    } else {
        if (qEnvironmentVariableIsEmpty("DISPLAY") && qEnvironmentVariableIsEmpty("WAYLAND_DISPLAY")
            && qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM")) {
            qWarning("quick-system-info-gui: no display available (DISPLAY and WAYLAND_DISPLAY are both unset); "
                    "a graphical session is required to run this program.");
            return EXIT_FAILURE;
        }

        app = std::make_unique<QApplication>(argc, argv);
    }

    app->setApplicationVersion(QStringLiteral(VERSION));
    app->setOrganizationName("MX-Linux");

    QCommandLineParser parser;
    parser.setApplicationDescription(QObject::tr("This tool displays a the quick system info report in a gui."));
    parser.addHelpOption();
    parser.addVersionOption();
    parser.process(*app);

    QApplication::setWindowIcon(QIcon::fromTheme(app->applicationName()));

    QTranslator qtTran;
    if (qtTran.load(QLocale::system(), "qt", "_", QLibraryInfo::path(QLibraryInfo::TranslationsPath)))
        app->installTranslator(&qtTran);

    QTranslator qtBaseTran;
    if (qtBaseTran.load("qtbase_" + QLocale::system().name(), QLibraryInfo::path(QLibraryInfo::TranslationsPath)))
        app->installTranslator(&qtBaseTran);

    QTranslator appTran;
    if (appTran.load(app->applicationName() + "_" + QLocale::system().name(), appPath("share/" + app->applicationName() + "/locale")))
        app->installTranslator(&appTran);

    if (getuid() != 0) {
        MainWindow w(parser);
        w.show();
        return QApplication::exec();
    } else {
        QApplication::beep();
        QMessageBox::critical(nullptr, QObject::tr("Error"), QApplication::tr("You must run this program as normal user."));
        return EXIT_FAILURE;
    }
}
